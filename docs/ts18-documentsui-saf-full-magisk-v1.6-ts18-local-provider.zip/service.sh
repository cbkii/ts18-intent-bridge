#!/system/bin/sh
# TS18 DocumentsUI SAF Full configurable boot normaliser.
# Bounded, user-0 by default, no destructive partition or firmware changes.

MODDIR=${0%/*}
MODID=ts18_documentsui_saf_full_v16
CONFIG=/data/adb/ts18-documentsui-saf.conf
LOG=/data/local/tmp/ts18-documentsui-saf-full.log
PROBE_DIR=/data/local/tmp/ts18-documentsui-saf-probes
STAMP=$(date '+%F %T %z' 2>/dev/null || echo unknown-time)

# Defaults. Runtime config can override recognised keys only.
REQUIRE_SDK_29=1
TARGET_USER=0
BOOT_WAIT_ATTEMPTS=60
BOOT_WAIT_SECONDS=2
ROOT_WAIT_ATTEMPTS=12
ROOT_WAIT_SECONDS=5
FIX_REMOVE_OLD_MODULES=1
FIX_REMOVE_USER_APK_SHADOWS=1
FIX_DISABLE_GOOGLE_AML_DOCUMENTSUI=1
FIX_ENABLE_AOSP_DOCUMENTSUI=1
FIX_ENABLE_DOCUMENTSUI_COMPONENTS=1
FIX_ENABLE_EXTERNALSTORAGE_PROVIDER=1
FIX_ENABLE_EXTERNALSTORAGE_COMPONENTS=1
FIX_DISABLE_EXTERNALSTORAGE_TEST_PROVIDER=0
FIX_ENABLE_MEDIA_PROVIDER=1
FIX_ENABLE_DOWNLOAD_PROVIDER=1
FIX_UNSUSPEND_SAF_PACKAGES=1
FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER=1
FIX_GRANT_TS18_LOCAL_SAF_PROVIDER_RUNTIME_PERMS=1
FIX_SET_TS18_LOCAL_SAF_PROVIDER_APPOPS=1
FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER_COMPONENTS=1
FIX_WAIT_FOR_TS18_LOCAL_SAF_ROOT=1
FIX_GRANT_DOCUMENTSUI_RUNTIME_PERMS=1
FIX_SET_DOCUMENTSUI_APPOPS=1
FIX_GRANT_EXTERNALSTORAGE_RUNTIME_PERMS=1
FIX_SET_EXTERNALSTORAGE_APPOPS=1
FIX_SET_ADVANCED_ROOT_PREFS=1
FIX_WRITE_EXACT_INCLUDE_DEVICE_ROOT_PREF=1
FIX_WRITE_MULTIPLE_PREF_NAMES=1
FIX_CREATE_DOCSUI_DATA_DIR_IF_ABSENT=1
FIX_RESET_LAST_ACCESS_DB=1
FIX_RESET_PICK_COUNT_DB=0
FIX_CREATE_STANDARD_INTERNAL_DIRS=1
FIX_REPAIR_STORAGE_SYMLINKS=1
FIX_START_USER_0=1
FIX_STORAGE_VOLUME_REFRESH=1
FIX_MOUNT_UNMOUNTED_EMULATED_VOLUMES=1
FIX_PROVIDER_WARMUP_QUERIES=1
FIX_CLEAR_EXTERNALSTORAGE_DATA_IF_NO_ROOT=0
FIX_FORCE_STOP_DOCUMENTSUI=1
FIX_FORCE_STOP_EXTERNALSTORAGE=1
FIX_FORCE_STOP_MEDIA_PROVIDER=0
FIX_FORCE_STOP_DOWNLOAD_PROVIDER=0
FIX_WAIT_FOR_PRIMARY_ROOT=1
FIX_BROADCAST_MEDIA_MOUNTED=1
FIX_SET_DEVICE_NAME_IF_EMPTY=1
FIX_VDC_USER_REFRESH=0
FIX_REMOUNT_EMULATED_VOLUME=0
FIX_LOG_PERMISSION_PROOF=1
FIX_LOG_STORAGE_DUMPS=1
FIX_LOG_PROVIDER_QUERIES=1
FIX_LOG_DOCUMENTSUI_RESOLUTION=1
FIX_LOG_RECENT_PROVIDER_LOGCAT=1
FIX_LAUNCH_TEST_INTENTS=0

if [ ! -f "$CONFIG" ] && [ -f "$MODDIR/config.default" ]; then
  mkdir -p /data/adb 2>/dev/null || true
  cp -f "$MODDIR/config.default" "$CONFIG" 2>/dev/null || true
  chmod 0644 "$CONFIG" 2>/dev/null || true
fi

valid_scalar() { case "$1" in ''|*[!A-Za-z0-9_./:-]*) return 1 ;; *) return 0 ;; esac; }
is_on() { case "$1" in 1|true|TRUE|yes|YES|on|ON|enabled|ENABLED) return 0 ;; *) return 1 ;; esac; }
valid_user() { case "$1" in ''|*[!0-9]*) return 1 ;; *) return 0 ;; esac; }
log_line() { echo "$@"; }

load_config_safe() {
  cfg="$1"
  [ -f "$cfg" ] || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in ''|'#'*) continue ;; *=*) ;; *) continue ;; esac
    key=${line%%=*}
    val=${line#*=}
    case "$key" in
      REQUIRE_SDK_29|TARGET_USER|BOOT_WAIT_ATTEMPTS|BOOT_WAIT_SECONDS|ROOT_WAIT_ATTEMPTS|ROOT_WAIT_SECONDS|FIX_REMOVE_OLD_MODULES|FIX_REMOVE_USER_APK_SHADOWS|FIX_DISABLE_GOOGLE_AML_DOCUMENTSUI|FIX_ENABLE_AOSP_DOCUMENTSUI|FIX_ENABLE_DOCUMENTSUI_COMPONENTS|FIX_ENABLE_EXTERNALSTORAGE_PROVIDER|FIX_ENABLE_EXTERNALSTORAGE_COMPONENTS|FIX_DISABLE_EXTERNALSTORAGE_TEST_PROVIDER|FIX_ENABLE_MEDIA_PROVIDER|FIX_ENABLE_DOWNLOAD_PROVIDER|FIX_UNSUSPEND_SAF_PACKAGES|FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER|FIX_GRANT_TS18_LOCAL_SAF_PROVIDER_RUNTIME_PERMS|FIX_SET_TS18_LOCAL_SAF_PROVIDER_APPOPS|FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER_COMPONENTS|FIX_WAIT_FOR_TS18_LOCAL_SAF_ROOT|FIX_GRANT_DOCUMENTSUI_RUNTIME_PERMS|FIX_SET_DOCUMENTSUI_APPOPS|FIX_GRANT_EXTERNALSTORAGE_RUNTIME_PERMS|FIX_SET_EXTERNALSTORAGE_APPOPS|FIX_SET_ADVANCED_ROOT_PREFS|FIX_WRITE_EXACT_INCLUDE_DEVICE_ROOT_PREF|FIX_WRITE_MULTIPLE_PREF_NAMES|FIX_CREATE_DOCSUI_DATA_DIR_IF_ABSENT|FIX_RESET_LAST_ACCESS_DB|FIX_RESET_PICK_COUNT_DB|FIX_CREATE_STANDARD_INTERNAL_DIRS|FIX_REPAIR_STORAGE_SYMLINKS|FIX_START_USER_0|FIX_STORAGE_VOLUME_REFRESH|FIX_MOUNT_UNMOUNTED_EMULATED_VOLUMES|FIX_PROVIDER_WARMUP_QUERIES|FIX_CLEAR_EXTERNALSTORAGE_DATA_IF_NO_ROOT|FIX_FORCE_STOP_DOCUMENTSUI|FIX_FORCE_STOP_EXTERNALSTORAGE|FIX_FORCE_STOP_MEDIA_PROVIDER|FIX_FORCE_STOP_DOWNLOAD_PROVIDER|FIX_WAIT_FOR_PRIMARY_ROOT|FIX_BROADCAST_MEDIA_MOUNTED|FIX_SET_DEVICE_NAME_IF_EMPTY|FIX_VDC_USER_REFRESH|FIX_REMOUNT_EMULATED_VOLUME|FIX_LOG_PERMISSION_PROOF|FIX_LOG_STORAGE_DUMPS|FIX_LOG_PROVIDER_QUERIES|FIX_LOG_DOCUMENTSUI_RESOLUTION|FIX_LOG_RECENT_PROVIDER_LOGCAT|FIX_LAUNCH_TEST_INTENTS)
        if valid_scalar "$val"; then eval "$key=\$val"; else echo "ignored unsafe config value: $key"; fi
        ;;
    esac
  done < "$cfg"
}
load_config_safe "$CONFIG"

pkg_exists() { pm path "$1" >/dev/null 2>&1; }
cmd_exists() { command -v "$1" >/dev/null 2>&1 || [ -x "/system/bin/$1" ]; }

safe_pm_enable() {
  pkg="$1"
  if pkg_exists "$pkg"; then
    pm install-existing --user "$TARGET_USER" "$pkg" >/dev/null 2>&1 && log_line "install-existing ok: $pkg" || log_line "install-existing skipped/failed: $pkg"
    cmd package install-existing --user "$TARGET_USER" "$pkg" >/dev/null 2>&1 && log_line "cmd install-existing ok: $pkg" || log_line "cmd install-existing skipped/failed: $pkg"
    pm enable --user "$TARGET_USER" "$pkg" >/dev/null 2>&1 && log_line "pm enable ok: $pkg" || log_line "pm enable skipped/failed: $pkg"
    cmd package set-enabled-setting "$pkg" enabled --user "$TARGET_USER" >/dev/null 2>&1 && log_line "cmd enable ok: $pkg" || log_line "cmd enable skipped/failed: $pkg"
  else
    log_line "package absent: $pkg"
  fi
}

safe_enable_component() {
  component="$1"
  cmd package set-enabled-setting "$component" enabled --user "$TARGET_USER" >/dev/null 2>&1 && log_line "component enable ok: $component" || log_line "component enable skipped/failed: $component"
  pm enable --user "$TARGET_USER" "$component" >/dev/null 2>&1 && log_line "pm component enable ok: $component" || true
}

safe_disable_component() {
  component="$1"
  cmd package set-enabled-setting "$component" disabled --user "$TARGET_USER" >/dev/null 2>&1 && log_line "component disable ok: $component" || log_line "component disable skipped/failed: $component"
  pm disable --user "$TARGET_USER" "$component" >/dev/null 2>&1 && log_line "pm component disable ok: $component" || true
}

safe_grant() {
  pkg="$1"; perm="$2"
  if pkg_exists "$pkg"; then pm grant "$pkg" "$perm" >/dev/null 2>&1 && log_line "pm grant ok: $pkg $perm" || log_line "pm grant skipped/failed: $pkg $perm"; fi
}

safe_appop() {
  pkg="$1"; op="$2"
  if pkg_exists "$pkg"; then
    appops set "$pkg" "$op" allow >/dev/null 2>&1 && log_line "appops ok: $pkg $op allow" || log_line "appops skipped/failed: $pkg $op"
    cmd appops set "$pkg" "$op" allow >/dev/null 2>&1 && log_line "cmd appops ok: $pkg $op allow" || true
  fi
}

pkg_uid() { cmd package list packages -U "$1" 2>/dev/null | sed -n 's/.* uid://p' | head -n 1; }

remove_user_shadows() {
  for pkg in com.google.android.documentsui com.android.documentsui; do
    paths=$(pm path "$pkg" 2>/dev/null || true)
    case "$paths" in
      *package:/data/app/*)
        log_line "user-installed DocumentsUI shadow detected: $pkg"
        pm uninstall --user "$TARGET_USER" "$pkg" >/dev/null 2>&1 && log_line "uninstall shadow ok: $pkg" || log_line "uninstall shadow skipped/failed: $pkg"
        ;;
      *) log_line "no /data/app shadow for: $pkg" ;;
    esac
  done
}

unsuspend_saf_packages() {
  for pkg in com.android.documentsui com.ts18.safprovider com.android.externalstorage com.android.providers.downloads com.android.providers.downloads.ui com.android.providers.media; do
    pkg_exists "$pkg" || continue
    cmd package unsuspend --user "$TARGET_USER" "$pkg" >/dev/null 2>&1 && log_line "unsuspend ok: $pkg" || log_line "unsuspend skipped/failed: $pkg"
  done
}

enable_externalstorage_components() {
  safe_enable_component com.android.externalstorage/.ExternalStorageProvider
  safe_enable_component com.android.externalstorage/.MountReceiver
  if is_on "$FIX_DISABLE_EXTERNALSTORAGE_TEST_PROVIDER"; then
    safe_disable_component com.android.externalstorage/.TestDocumentsProvider
  else
    log_line "leaving ExternalStorageProvider test provider unchanged; toggle FIX_DISABLE_EXTERNALSTORAGE_TEST_PROVIDER=1 to disable"
  fi
}


enable_ts18_safprovider_components() {
  safe_enable_component com.ts18.safprovider/com.ts18.safprovider.TS18DocumentsProvider
}

has_ts18_saf_root() {
  tmp="$PROBE_DIR/ts18-saf-root-probe.txt"
  content_query_uri 'content://com.ts18.safprovider.documents/root' "$tmp"
  grep -Eq 'root_id=ts18_internal|document_id=ts18_internal:|TS18 Internal Storage' "$tmp" && return 0
  return 1
}

wait_for_ts18_saf_root() {
  is_on "$FIX_WAIT_FOR_TS18_LOCAL_SAF_ROOT" || { log_line "disabled by config: FIX_WAIT_FOR_TS18_LOCAL_SAF_ROOT"; return 1; }
  n=0
  while [ "$n" -lt "$ROOT_WAIT_ATTEMPTS" ]; do
    if has_ts18_saf_root; then log_line "TS18 Local DocumentsProvider root visible after wait attempt $n"; return 0; fi
    n=$((n + 1)); log_line "TS18 Local DocumentsProvider root not visible yet; wait $n/$ROOT_WAIT_ATTEMPTS"; sleep "$ROOT_WAIT_SECONDS"
  done
  log_line "TS18 Local DocumentsProvider root still not visible after wait"
  return 1
}

enable_documentsui_components() {
  safe_enable_component com.android.documentsui/.LauncherActivity
  safe_enable_component com.android.documentsui/.files.FilesActivity
  safe_enable_component com.android.documentsui/.picker.PickActivity
  safe_enable_component com.android.documentsui/.ScopedAccessActivity
  safe_enable_component com.android.documentsui/.inspector.InspectorActivity
}

ensure_docsui_data_dir() {
  pkg="$1"; data="/data/user/$TARGET_USER/$pkg"
  [ -d "$data" ] && return 0
  is_on "$FIX_CREATE_DOCSUI_DATA_DIR_IF_ABSENT" || { log_line "data dir absent and create fallback disabled: $data"; return 1; }
  uid=$(pkg_uid "$pkg")
  case "$uid" in ''|*[!0-9]*) log_line "data dir create skipped; cannot resolve uid for: $pkg"; return 1 ;; esac
  mkdir -p "$data/shared_prefs" "$data/databases" 2>/dev/null || { log_line "data dir create failed: $data"; return 1; }
  chown -R "$uid:$uid" "$data" 2>/dev/null || true
  chmod 0700 "$data" 2>/dev/null || true
  chmod 0771 "$data/shared_prefs" "$data/databases" 2>/dev/null || true
  restorecon -RF "$data" >/dev/null 2>&1 || true
  log_line "data dir created fallback: $data uid=$uid"
  return 0
}

write_pref_file() {
  pkg="$1"; data="/data/user/$TARGET_USER/$pkg"
  [ -d "$data" ] || data="/data/data/$pkg"
  [ -d "$data" ] || ensure_docsui_data_dir "$pkg" || return 0
  data="/data/user/$TARGET_USER/$pkg"; [ -d "$data" ] || data="/data/data/$pkg"
  prefdir="$data/shared_prefs"
  mkdir -p "$prefdir" 2>/dev/null || { log_line "prefs skipped, cannot create: $prefdir"; return 0; }
  owner=$(stat -c '%u:%g' "$data" 2>/dev/null || echo '')
  nowstamp=$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)
  names="${pkg}_preferences.xml"
  is_on "$FIX_WRITE_MULTIPLE_PREF_NAMES" && names="$names documentsui_preferences.xml preferences.xml com.android.documentsui_preferences.xml"
  exact_include_line=''
  is_on "$FIX_WRITE_EXACT_INCLUDE_DEVICE_ROOT_PREF" && exact_include_line='    <boolean name="includeDeviceRoot" value="true" />'
  for name in $names; do
    pref="$prefdir/$name"; tmp="$pref.tmp.$$"
    [ -f "$pref" ] && [ ! -f "$pref.ts18bak" ] && cp -p "$pref" "$pref.ts18bak" 2>/dev/null || true
    [ -f "$pref" ] && cp -p "$pref" "$pref.ts18bak.$nowstamp" 2>/dev/null || true
    cat > "$tmp" <<PREFEOF
<?xml version="1.0" encoding="utf-8" standalone="yes" ?>
<map>
    <!-- Android 10 AOSP DocumentsUI exact key: ScopedPreferences.INCLUDE_DEVICE_ROOT -->
$exact_include_line
    <boolean name="advancedDevices" value="true" />
    <boolean name="fileSize" value="true" />
    <boolean name="showAdvanced" value="true" />
    <boolean name="showDeviceStorageOption" value="true" />
    <boolean name="showDeviceRoot" value="true" />
    <boolean name="show_advanced" value="true" />
    <boolean name="show_advanced_devices" value="true" />
    <boolean name="display_advanced_devices" value="true" />
    <boolean name="displayFileSize" value="true" />
    <boolean name="display_file_size" value="true" />
    <boolean name="showHiddenFiles" value="true" />
</map>
PREFEOF
    if mv -f "$tmp" "$pref" 2>/dev/null; then
      [ -n "$owner" ] && chown "$owner" "$pref" "$prefdir" 2>/dev/null || true
      chmod 0600 "$pref" 2>/dev/null || true
      restorecon "$pref" "$prefdir" >/dev/null 2>&1 || true
      log_line "wrote DocumentsUI pref file: $pref"
    else
      rm -f "$tmp" 2>/dev/null || true
      log_line "failed to write DocumentsUI pref file: $pref"
    fi
  done
}

reset_docsui_state() {
  pkg=com.android.documentsui; data="/data/user/$TARGET_USER/$pkg"; [ -d "$data" ] || data="/data/data/$pkg"; [ -d "$data" ] || return 0
  nowstamp=$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)
  if is_on "$FIX_RESET_LAST_ACCESS_DB"; then
    for f in "$data"/databases/lastAccess.db "$data"/databases/lastAccess.db-journal "$data"/databases/lastAccess.db-wal "$data"/databases/lastAccess.db-shm; do [ -e "$f" ] && mv "$f" "$f.ts18bak.$nowstamp" 2>/dev/null && log_line "moved stale lastAccess db: $f"; done
  fi
  if is_on "$FIX_RESET_PICK_COUNT_DB"; then
    for f in "$data"/databases/pickCountRecord.db "$data"/databases/pickCountRecord.db-journal "$data"/databases/pickCountRecord.db-wal "$data"/databases/pickCountRecord.db-shm; do [ -e "$f" ] && mv "$f" "$f.ts18bak.$nowstamp" 2>/dev/null && log_line "moved pickCount db: $f"; done
  fi
}

create_standard_internal_dirs() {
  base="/storage/emulated/$TARGET_USER"; raw="/data/media/$TARGET_USER"
  if [ ! -d "$base" ] && [ ! -d "$raw" ]; then log_line "standard dirs skipped; no internal shared storage base for user $TARGET_USER"; return 0; fi
  for d in Alarms Audiobooks DCIM Documents Download Movies Music Notifications Pictures Podcasts Ringtones Photos; do
    made=0
    [ -d "$raw" ] && mkdir -p "$raw/$d" 2>/dev/null && made=1
    [ "$made" != "1" ] && [ -d "$base" ] && mkdir -p "$base/$d" 2>/dev/null && made=1
    if [ "$made" = "1" ]; then
      [ -d "$raw/$d" ] && chown 1023:1023 "$raw/$d" 2>/dev/null || true
      [ -d "$raw/$d" ] && chmod 0775 "$raw/$d" 2>/dev/null || true
      [ -d "$raw/$d" ] && restorecon "$raw/$d" >/dev/null 2>&1 || true
      log_line "standard dir ready: $d"
    else log_line "standard dir failed/skipped: $d"; fi
  done
}

repair_storage_symlinks() {
  [ -e /sdcard ] && [ ! -L /sdcard ] && log_line "storage symlink check: /sdcard exists but is not symlink; not modifying"
  [ -e /storage/self/primary ] || log_line "storage symlink check: /storage/self/primary absent"
  [ -e "/storage/emulated/$TARGET_USER" ] || log_line "storage symlink check: /storage/emulated/$TARGET_USER absent"
  # Do not create /storage or /mnt links. Those are vold/sdcardfs-owned app namespace views.
}

start_user_0() {
  cmd user start "$TARGET_USER" >/dev/null 2>&1 && log_line "cmd user start ok: $TARGET_USER" || log_line "cmd user start skipped/failed: $TARGET_USER"
  am start-user "$TARGET_USER" >/dev/null 2>&1 && log_line "am start-user ok: $TARGET_USER" || log_line "am start-user skipped/failed: $TARGET_USER"
}

set_device_name_if_empty() {
  current=$(settings get global device_name 2>/dev/null || echo '')
  case "$current" in ''|null) settings put global device_name TS18 >/dev/null 2>&1 && log_line "device_name set to TS18" || log_line "device_name set skipped/failed" ;; *) log_line "device_name already set: $current" ;; esac
}

storage_list_volumes() { sm list-volumes all 2>/dev/null || sm list-volumes 2>/dev/null || true; }
sm_supports_mount() { help=$(sm 2>&1 || true); echo "$help" | grep -q " mount " && return 0; echo "$help" | grep -q "sm mount" && return 0; return 1; }

refresh_storage_volumes() {
  log_line "storage volumes before refresh:"; storage_list_volumes | sed 's/^/  /'
  cmd_exists sm || { log_line "sm command absent; storage volume refresh skipped"; return 0; }
  if is_on "$FIX_MOUNT_UNMOUNTED_EMULATED_VOLUMES" && sm_supports_mount; then
    storage_list_volumes | while IFS=' ' read -r vol state rest; do
      case "$vol" in emulated*) ;; *) continue ;; esac
      case "$state" in mounted|mounted_ro) log_line "emulated volume already mounted: $vol $state" ;; *) sm mount "$vol" >/dev/null 2>&1 && log_line "sm mount ok: $vol" || log_line "sm mount failed/skipped: $vol state=$state" ;; esac
    done
  else log_line "sm mount unavailable or disabled"; fi
  if is_on "$FIX_REMOUNT_EMULATED_VOLUME" && sm_supports_mount; then
    storage_list_volumes | while IFS=' ' read -r vol state rest; do case "$vol" in emulated*) ;; *) continue ;; esac; sm unmount "$vol" >/dev/null 2>&1 && log_line "sm unmount ok: $vol" || log_line "sm unmount skipped/failed: $vol"; sleep 1; sm mount "$vol" >/dev/null 2>&1 && log_line "sm remount ok: $vol" || log_line "sm remount failed/skipped: $vol"; done
  fi
  log_line "storage volumes after refresh:"; storage_list_volumes | sed 's/^/  /'
}

vdc_user_refresh() {
  is_on "$FIX_VDC_USER_REFRESH" || { log_line "disabled by config: FIX_VDC_USER_REFRESH"; return 0; }
  cmd_exists vdc || { log_line "vdc absent; vdc refresh skipped"; return 0; }
  vdc volume user_added "$TARGET_USER" 0 >/dev/null 2>&1 && log_line "vdc volume user_added ok" || log_line "vdc volume user_added skipped/failed"
  vdc volume user_started "$TARGET_USER" >/dev/null 2>&1 && log_line "vdc volume user_started ok" || log_line "vdc volume user_started skipped/failed"
}

force_stop_selected() {
  is_on "$FIX_FORCE_STOP_DOCUMENTSUI" && { am force-stop com.android.documentsui >/dev/null 2>&1 || true; cmd activity kill com.android.documentsui >/dev/null 2>&1 || true; log_line "reloaded: com.android.documentsui"; }
  is_on "$FIX_FORCE_STOP_EXTERNALSTORAGE" && { am force-stop com.android.externalstorage >/dev/null 2>&1 || true; cmd activity kill com.android.externalstorage >/dev/null 2>&1 || true; log_line "reloaded: com.android.externalstorage"; }
  is_on "$FIX_FORCE_STOP_MEDIA_PROVIDER" && { am force-stop com.android.providers.media >/dev/null 2>&1 || true; cmd activity kill com.android.providers.media >/dev/null 2>&1 || true; log_line "reloaded: com.android.providers.media"; }
  is_on "$FIX_FORCE_STOP_DOWNLOAD_PROVIDER" && { am force-stop com.android.providers.downloads >/dev/null 2>&1 || true; cmd activity kill com.android.providers.downloads >/dev/null 2>&1 || true; log_line "reloaded: com.android.providers.downloads"; }
}

broadcast_media_mounted() {
  am broadcast --user "$TARGET_USER" -a android.intent.action.MEDIA_MOUNTED -d "file:///storage/emulated/$TARGET_USER" >/dev/null 2>&1 && log_line "MEDIA_MOUNTED broadcast sent for /storage/emulated/$TARGET_USER" || log_line "MEDIA_MOUNTED broadcast skipped/failed"
  am broadcast --user "$TARGET_USER" -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file:///storage/emulated/$TARGET_USER" >/dev/null 2>&1 && log_line "MEDIA_SCANNER broadcast sent for /storage/emulated/$TARGET_USER" || log_line "MEDIA_SCANNER broadcast skipped/failed"
}

content_query_uri() {
  uri="$1"; out="$2"
  mkdir -p "$PROBE_DIR" 2>/dev/null || true
  : > "$out"
  content --user "$TARGET_USER" query --uri "$uri" >> "$out" 2>&1 || \
    content query --user "$TARGET_USER" --uri "$uri" >> "$out" 2>&1 || \
    content query --uri "$uri" >> "$out" 2>&1 || true
}

has_primary_root() {
  tmp="$PROBE_DIR/root-probe.txt"
  content_query_uri 'content://com.android.externalstorage.documents/root' "$tmp"
  grep -Eq 'root_id=primary|root_id=home|document_id=primary:|primary:' "$tmp" && return 0
  return 1
}

warmup_provider_queries() {
  is_on "$FIX_PROVIDER_WARMUP_QUERIES" || { log_line "disabled by config: FIX_PROVIDER_WARMUP_QUERIES"; return 0; }
  mkdir -p "$PROBE_DIR" 2>/dev/null || true
  for uri in \
    'content://com.ts18.safprovider.documents/root' \
    'content://com.ts18.safprovider.documents/document/ts18_internal%3A' \
    'content://com.ts18.safprovider.documents/document/ts18_internal%3A/children' \
    'content://com.android.externalstorage.documents/root' \
    'content://com.android.externalstorage.documents/document/primary%3A' \
    'content://com.android.externalstorage.documents/document/primary%3A/children' \
    'content://com.android.externalstorage.documents/root/home' \
    'content://com.android.providers.downloads.documents/root'; do
    f="$PROBE_DIR/warmup-$(echo "$uri" | tr '/:%?' '_____').txt"
    content_query_uri "$uri" "$f"
    log_line "warmup query: $uri -> $(head -n 1 "$f" 2>/dev/null)"
  done
}

clear_externalstorage_if_no_root() {
  is_on "$FIX_CLEAR_EXTERNALSTORAGE_DATA_IF_NO_ROOT" || { log_line "disabled by config: FIX_CLEAR_EXTERNALSTORAGE_DATA_IF_NO_ROOT"; return 0; }
  if has_primary_root; then log_line "primary root already visible; not clearing ExternalStorageProvider data"; return 0; fi
  pm clear --user "$TARGET_USER" com.android.externalstorage >/dev/null 2>&1 && log_line "pm clear ok: com.android.externalstorage" || log_line "pm clear skipped/failed: com.android.externalstorage"
  am force-stop com.android.externalstorage >/dev/null 2>&1 || true
}

wait_for_primary_root() {
  is_on "$FIX_WAIT_FOR_PRIMARY_ROOT" || { log_line "disabled by config: FIX_WAIT_FOR_PRIMARY_ROOT"; return 1; }
  n=0
  while [ "$n" -lt "$ROOT_WAIT_ATTEMPTS" ]; do
    if has_primary_root; then log_line "primary/home root visible after wait attempt $n"; return 0; fi
    n=$((n + 1)); log_line "primary/home root not visible yet; wait $n/$ROOT_WAIT_ATTEMPTS"; sleep "$ROOT_WAIT_SECONDS"
  done
  log_line "primary/home root still not visible after wait"
  return 1
}

log_permission_proof() {
  is_on "$FIX_LOG_PERMISSION_PROOF" || { log_line "disabled by config: FIX_LOG_PERMISSION_PROOF"; return 0; }
  for pkg in com.android.documentsui com.ts18.safprovider com.android.externalstorage; do
    log_line "--- package proof: $pkg ---"
    pm path "$pkg" 2>&1 | sed 's/^/  /' || true
    pm dump "$pkg" 2>&1 | grep -E 'codePath=|privateFlags=|pkgFlags=|userId=|versionCode=|User 0:|enabled=|android.permission.MANAGE_DOCUMENTS|GET_APP_GRANTED_URI_PERMISSIONS|REMOVE_TASKS|CACHE_CONTENT|WRITE_MEDIA_STORAGE|MOUNT_UNMOUNT_FILESYSTEMS|READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE|provider|authority' | head -n 160 | sed 's/^/  /' || true
  done
  if pm dump com.android.documentsui 2>/dev/null | grep -q 'android.permission.MANAGE_DOCUMENTS: granted=true'; then
    log_line "permission proof ok: com.android.documentsui MANAGE_DOCUMENTS granted"
  else
    log_line "STOP: com.android.documentsui does not show MANAGE_DOCUMENTS granted. Root/Magisk cannot invent platform signing; priv-app overlay/allowlist must be active after reboot."
  fi
}

log_documentsui_resolution() {
  is_on "$FIX_LOG_DOCUMENTSUI_RESOLUTION" || { log_line "disabled by config: FIX_LOG_DOCUMENTSUI_RESOLUTION"; return 0; }
  log_line "--- DocumentsUI intent resolution ---"
  cmd package resolve-activity --brief -a android.intent.action.OPEN_DOCUMENT_TREE 2>&1 | sed 's/^/  /' || true
  cmd package resolve-activity --brief -a android.intent.action.OPEN_DOCUMENT -t '*/*' 2>&1 | sed 's/^/  /' || true
  cmd package resolve-activity --brief -a android.intent.action.GET_CONTENT -t '*/*' 2>&1 | sed 's/^/  /' || true
  cmd package query-activities -a android.intent.action.OPEN_DOCUMENT_TREE 2>&1 | head -n 120 | sed 's/^/  /' || true
}

log_storage_dumps() {
  is_on "$FIX_LOG_STORAGE_DUMPS" || { log_line "disabled by config: FIX_LOG_STORAGE_DUMPS"; return 0; }
  log_line "--- storage mounts ---"; grep -E ' /storage/| /mnt/runtime/| /mnt/media_rw|/data/media' /proc/mounts 2>/dev/null | sed 's/^/  /' || true
  log_line "--- ls storage bases ---"
  for p in /data/media /data/media/$TARGET_USER /storage /storage/emulated /storage/emulated/$TARGET_USER /storage/self/primary /mnt/runtime/default/emulated /mnt/runtime/default/emulated/$TARGET_USER /mnt/runtime/read/emulated/$TARGET_USER /mnt/runtime/write/emulated/$TARGET_USER /mnt/runtime/full/emulated/$TARGET_USER /mnt/media_rw /storage/usbdisk0 /storage/usbdisk1; do
    ls -ldZ "$p" 2>&1 | sed "s/^/  $p -> /"
  done
  log_line "--- sm volumes ---"; storage_list_volumes | sed 's/^/  /'
  log_line "--- primary storage uuid ---"; sm get-primary-storage-uuid 2>&1 | sed 's/^/  /' || true
  log_line "--- dumpsys mount/storage excerpt ---"
  dumpsys mount 2>&1 | grep -Ei 'VolumeInfo|emulated|public:|private|Primary|mPrimary|mountUserId|state=|path=|visible|fsUuid|internalPath' | head -n 220 | sed 's/^/  /' || true
  dumpsys storage 2>&1 | grep -Ei 'VolumeInfo|emulated|public:|private|Primary|mPrimary|state=|path=|visible|fsUuid|internalPath' | head -n 220 | sed 's/^/  /' || true
  log_line "--- external provider dump ---"; dumpsys activity provider com.android.externalstorage/.ExternalStorageProvider 2>&1 | head -n 220 | sed 's/^/  /' || true
}

log_provider_queries() {
  is_on "$FIX_LOG_PROVIDER_QUERIES" || { log_line "disabled by config: FIX_LOG_PROVIDER_QUERIES"; return 0; }
  mkdir -p "$PROBE_DIR" 2>/dev/null || true
  log_line "TS18LocalDocumentsProvider roots:"; content --user "$TARGET_USER" query --uri 'content://com.ts18.safprovider.documents/root' 2>&1 || content query --uri 'content://com.ts18.safprovider.documents/root' 2>&1 || true
  log_line "TS18LocalDocumentsProvider internal children:"; content --user "$TARGET_USER" query --uri 'content://com.ts18.safprovider.documents/document/ts18_internal%3A/children' 2>&1 || content query --uri 'content://com.ts18.safprovider.documents/document/ts18_internal%3A/children' 2>&1 || true
  log_line "ExternalStorageProvider roots:"; content --user "$TARGET_USER" query --uri 'content://com.android.externalstorage.documents/root' 2>&1 || content query --uri 'content://com.android.externalstorage.documents/root' 2>&1 || true
  log_line "ExternalStorageProvider primary document:"; content --user "$TARGET_USER" query --uri 'content://com.android.externalstorage.documents/document/primary%3A' 2>&1 || content query --uri 'content://com.android.externalstorage.documents/document/primary%3A' 2>&1 || true
  log_line "ExternalStorageProvider primary children:"; content --user "$TARGET_USER" query --uri 'content://com.android.externalstorage.documents/document/primary%3A/children' 2>&1 || content query --uri 'content://com.android.externalstorage.documents/document/primary%3A/children' 2>&1 || true
  log_line "DownloadsProvider roots:"; content --user "$TARGET_USER" query --uri 'content://com.android.providers.downloads.documents/root' 2>&1 || content query --uri 'content://com.android.providers.downloads.documents/root' 2>&1 || true
  log_line "MediaDocumentsProvider roots:"; content --user "$TARGET_USER" query --uri 'content://com.android.providers.media.documents/root' 2>&1 || content query --uri 'content://com.android.providers.media.documents/root' 2>&1 || true
}

log_recent_provider_logcat() {
  is_on "$FIX_LOG_RECENT_PROVIDER_LOGCAT" || { log_line "disabled by config: FIX_LOG_RECENT_PROVIDER_LOGCAT"; return 0; }
  log_line "--- recent provider/DocumentsUI logcat excerpt ---"
  logcat -d -t 500 2>/dev/null | grep -Ei 'DocumentsUI|ExternalStorage|DownloadStorageProvider|MediaDocumentsProvider|TS18LocalDocumentsProvider|com.ts18.safprovider|DocumentsProvider|MANAGE_DOCUMENTS|SecurityException|Failed to find provider|content://com.android.externalstorage' | tail -n 160 | sed 's/^/  /' || true
}

launch_test_intents() {
  is_on "$FIX_LAUNCH_TEST_INTENTS" || { log_line "disabled by config: FIX_LAUNCH_TEST_INTENTS"; return 0; }
  "$MODDIR/tools/ts18-saf-launch.sh" ts18 >> "$LOG" 2>&1 || true
}

{
  log_line "===== TS18 DocumentsUI SAF Full service.sh ====="
  log_line "time=$STAMP"
  log_line "module=$MODID"
  log_line "config=$CONFIG"
  log_line "display_id=$(getprop ro.build.display.id 2>/dev/null)"
  log_line "fingerprint=$(getprop ro.build.fingerprint 2>/dev/null)"
  log_line "sdk=$(getprop ro.build.version.sdk 2>/dev/null)"

  if ! valid_user "$TARGET_USER"; then log_line "STOP: invalid TARGET_USER=$TARGET_USER. This module deliberately refuses negative/all-user selectors such as -2."; exit 0; fi

  n=0
  while [ "$n" -lt "$BOOT_WAIT_ATTEMPTS" ]; do [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] && break; n=$((n + 1)); sleep "$BOOT_WAIT_SECONDS"; done
  log_line "boot_completed=$(getprop sys.boot_completed 2>/dev/null) waited=${n}x${BOOT_WAIT_SECONDS}s"

  if is_on "$REQUIRE_SDK_29" && [ "$(getprop ro.build.version.sdk 2>/dev/null)" != "29" ]; then log_line "STOP: SDK is not 29; refusing to normalise DocumentsUI state."; exit 0; fi

  log_line "[1/18] Package shadow cleanup"
  is_on "$FIX_REMOVE_USER_APK_SHADOWS" && remove_user_shadows || log_line "disabled by config: FIX_REMOVE_USER_APK_SHADOWS"

  log_line "[2/18] Start/verify user $TARGET_USER storage context"
  is_on "$FIX_START_USER_0" && start_user_0 || log_line "disabled by config: FIX_START_USER_0"
  is_on "$FIX_SET_DEVICE_NAME_IF_EMPTY" && set_device_name_if_empty || log_line "disabled by config: FIX_SET_DEVICE_NAME_IF_EMPTY"

  log_line "[3/18] Enable DocumentsUI and SAF provider packages"
  is_on "$FIX_ENABLE_AOSP_DOCUMENTSUI" && safe_pm_enable com.android.documentsui || log_line "disabled by config: FIX_ENABLE_AOSP_DOCUMENTSUI"
  is_on "$FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER" && safe_pm_enable com.ts18.safprovider || log_line "disabled by config: FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER"
  is_on "$FIX_ENABLE_EXTERNALSTORAGE_PROVIDER" && safe_pm_enable com.android.externalstorage || log_line "disabled by config: FIX_ENABLE_EXTERNALSTORAGE_PROVIDER"
  is_on "$FIX_ENABLE_MEDIA_PROVIDER" && safe_pm_enable com.android.providers.media || log_line "disabled by config: FIX_ENABLE_MEDIA_PROVIDER"
  if is_on "$FIX_ENABLE_DOWNLOAD_PROVIDER"; then safe_pm_enable com.android.providers.downloads; safe_pm_enable com.android.providers.downloads.ui; else log_line "disabled by config: FIX_ENABLE_DOWNLOAD_PROVIDER"; fi
  is_on "$FIX_UNSUSPEND_SAF_PACKAGES" && unsuspend_saf_packages || log_line "disabled by config: FIX_UNSUSPEND_SAF_PACKAGES"

  log_line "[4/18] Enable DocumentsUI components"
  is_on "$FIX_ENABLE_DOCUMENTSUI_COMPONENTS" && enable_documentsui_components || log_line "disabled by config: FIX_ENABLE_DOCUMENTSUI_COMPONENTS"

  log_line "[5/18] Enable ExternalStorageProvider and TS18 Local DocumentsProvider components"
  is_on "$FIX_ENABLE_EXTERNALSTORAGE_COMPONENTS" && enable_externalstorage_components || log_line "disabled by config: FIX_ENABLE_EXTERNALSTORAGE_COMPONENTS"
  is_on "$FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER_COMPONENTS" && enable_ts18_safprovider_components || log_line "disabled by config: FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER_COMPONENTS"

  log_line "[6/18] Disable competing Google/AML DocumentsUI if present"
  if is_on "$FIX_DISABLE_GOOGLE_AML_DOCUMENTSUI"; then if pkg_exists com.google.android.documentsui; then pm disable-user --user "$TARGET_USER" com.google.android.documentsui >/dev/null 2>&1 && log_line "disabled competing package: com.google.android.documentsui" || log_line "could not disable competing package: com.google.android.documentsui"; else log_line "no competing Google/AML DocumentsUI package installed"; fi; else log_line "disabled by config: FIX_DISABLE_GOOGLE_AML_DOCUMENTSUI"; fi

  log_line "[7/18] Runtime storage grants"
  if is_on "$FIX_GRANT_DOCUMENTSUI_RUNTIME_PERMS"; then safe_grant com.android.documentsui android.permission.READ_EXTERNAL_STORAGE; safe_grant com.android.documentsui android.permission.WRITE_EXTERNAL_STORAGE; safe_grant com.android.documentsui android.permission.ACCESS_MEDIA_LOCATION; else log_line "disabled by config: FIX_GRANT_DOCUMENTSUI_RUNTIME_PERMS"; fi
  if is_on "$FIX_GRANT_TS18_LOCAL_SAF_PROVIDER_RUNTIME_PERMS"; then safe_grant com.ts18.safprovider android.permission.READ_EXTERNAL_STORAGE; safe_grant com.ts18.safprovider android.permission.WRITE_EXTERNAL_STORAGE; else log_line "disabled by config: FIX_GRANT_TS18_LOCAL_SAF_PROVIDER_RUNTIME_PERMS"; fi
  if is_on "$FIX_GRANT_EXTERNALSTORAGE_RUNTIME_PERMS"; then safe_grant com.android.externalstorage android.permission.READ_EXTERNAL_STORAGE; safe_grant com.android.externalstorage android.permission.WRITE_EXTERNAL_STORAGE; else log_line "disabled by config: FIX_GRANT_EXTERNALSTORAGE_RUNTIME_PERMS"; fi

  log_line "[8/18] Storage appops"
  if is_on "$FIX_SET_DOCUMENTSUI_APPOPS"; then for op in LEGACY_STORAGE android:legacy_storage READ_EXTERNAL_STORAGE WRITE_EXTERNAL_STORAGE ACCESS_MEDIA_LOCATION; do safe_appop com.android.documentsui "$op"; done; else log_line "disabled by config: FIX_SET_DOCUMENTSUI_APPOPS"; fi
  if is_on "$FIX_SET_TS18_LOCAL_SAF_PROVIDER_APPOPS"; then for op in LEGACY_STORAGE android:legacy_storage READ_EXTERNAL_STORAGE WRITE_EXTERNAL_STORAGE; do safe_appop com.ts18.safprovider "$op"; done; else log_line "disabled by config: FIX_SET_TS18_LOCAL_SAF_PROVIDER_APPOPS"; fi
  if is_on "$FIX_SET_EXTERNALSTORAGE_APPOPS"; then for op in LEGACY_STORAGE android:legacy_storage READ_EXTERNAL_STORAGE WRITE_EXTERNAL_STORAGE; do safe_appop com.android.externalstorage "$op"; done; else log_line "disabled by config: FIX_SET_EXTERNALSTORAGE_APPOPS"; fi

  log_line "[9/18] Permission/signing proof before root repair"
  log_permission_proof

  log_line "[10/18] Shared-storage directory preparation"
  is_on "$FIX_CREATE_STANDARD_INTERNAL_DIRS" && create_standard_internal_dirs || log_line "disabled by config: FIX_CREATE_STANDARD_INTERNAL_DIRS"
  is_on "$FIX_REPAIR_STORAGE_SYMLINKS" && repair_storage_symlinks || log_line "disabled by config: FIX_REPAIR_STORAGE_SYMLINKS"

  log_line "[11/18] Storage volume refresh"
  is_on "$FIX_STORAGE_VOLUME_REFRESH" && refresh_storage_volumes || log_line "disabled by config: FIX_STORAGE_VOLUME_REFRESH"
  vdc_user_refresh

  log_line "[12/18] Advanced/device-root prefs and stale last-access state"
  is_on "$FIX_FORCE_STOP_DOCUMENTSUI" && am force-stop com.android.documentsui >/dev/null 2>&1 || true
  is_on "$FIX_SET_ADVANCED_ROOT_PREFS" && write_pref_file com.android.documentsui || log_line "disabled by config: FIX_SET_ADVANCED_ROOT_PREFS"
  reset_docsui_state

  log_line "[13/18] Targeted provider reload and warmup"
  force_stop_selected
  warmup_provider_queries
  clear_externalstorage_if_no_root
  force_stop_selected
  warmup_provider_queries

  log_line "[14/18] Media mount notification"
  is_on "$FIX_BROADCAST_MEDIA_MOUNTED" && broadcast_media_mounted || log_line "disabled by config: FIX_BROADCAST_MEDIA_MOUNTED"

  log_line "[15/18] Wait for TS18 Local provider root and ExternalStorageProvider primary/home root"
  if wait_for_ts18_saf_root; then log_line "TS18 Local DocumentsProvider root present"; else log_line "STOP: TS18 Local DocumentsProvider root absent. Check package install, provider manifest/permission, and storage permission grants."; fi
  if wait_for_primary_root; then log_line "primary/home root present"; else log_line "ExternalStorageProvider still has no primary/home root; TS18 Local DocumentsProvider is intended to bypass this failure path."; fi

  log_line "[16/18] DocumentsUI resolution and optional launch test"
  log_documentsui_resolution
  launch_test_intents

  log_line "[17/18] Storage/provider/root dumps"
  log_storage_dumps
  log_provider_queries

  log_line "[18/18] Recent SAF/provider logcat"
  log_recent_provider_logcat
  log_line "===== done ====="
} >> "$LOG" 2>&1

exit 0
