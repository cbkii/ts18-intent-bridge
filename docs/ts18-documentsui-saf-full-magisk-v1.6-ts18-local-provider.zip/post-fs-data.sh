#!/system/bin/sh
# TS18 DocumentsUI SAF Full early shared-storage preparation.
# Keep this bounded: Magisk post-fs-data blocks boot.

MODDIR=${0%/*}
CONFIG=/data/adb/ts18-documentsui-saf.conf
LOG=/data/local/tmp/ts18-documentsui-saf-full.log
TARGET_USER=0
FIX_POSTFSDATA_PREPARE_DATA_MEDIA=1
FIX_POSTFSDATA_RESTORECON_DATA_MEDIA=1
FIX_CREATE_STANDARD_INTERNAL_DIRS=1

if [ ! -f "$CONFIG" ] && [ -f "$MODDIR/config.default" ]; then
  mkdir -p /data/adb 2>/dev/null || true
  cp -f "$MODDIR/config.default" "$CONFIG" 2>/dev/null || true
  chmod 0644 "$CONFIG" 2>/dev/null || true
fi

valid_scalar() {
  case "$1" in ''|*[!A-Za-z0-9_./:-]*) return 1 ;; *) return 0 ;; esac
}

load_config_safe() {
  cfg="$1"
  [ -f "$cfg" ] || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in ''|'#'*) continue ;; *=*) ;; *) continue ;; esac
    key=${line%%=*}; val=${line#*=}
    case "$key" in
      TARGET_USER|FIX_POSTFSDATA_PREPARE_DATA_MEDIA|FIX_POSTFSDATA_RESTORECON_DATA_MEDIA|FIX_CREATE_STANDARD_INTERNAL_DIRS)
        valid_scalar "$val" && eval "$key=\$val"
        ;;
    esac
  done < "$cfg"
}

is_on() { case "$1" in 1|true|TRUE|yes|YES|on|ON|enabled|ENABLED) return 0 ;; *) return 1 ;; esac; }
valid_user() { case "$1" in ''|*[!0-9]*) return 1 ;; *) return 0 ;; esac; }

load_config_safe "$CONFIG"

{
  echo "===== TS18 DocumentsUI SAF post-fs-data.sh ====="
  echo "time=$(date '+%F %T %z' 2>/dev/null || echo unknown-time)"
  echo "target_user=$TARGET_USER"

  if ! valid_user "$TARGET_USER"; then
    echo "STOP: invalid TARGET_USER=$TARGET_USER"
    exit 0
  fi

  if is_on "$FIX_POSTFSDATA_PREPARE_DATA_MEDIA"; then
    raw="/data/media/$TARGET_USER"
    if [ -d /data/media ]; then
      mkdir -p "$raw" 2>/dev/null || echo "prepare failed: $raw"
      chown 1023:1023 "$raw" 2>/dev/null || true
      chmod 0775 "$raw" 2>/dev/null || true
      if is_on "$FIX_CREATE_STANDARD_INTERNAL_DIRS"; then
        for d in Alarms Audiobooks DCIM Documents Download Movies Music Notifications Pictures Podcasts Ringtones Photos; do
          mkdir -p "$raw/$d" 2>/dev/null || true
          chown 1023:1023 "$raw/$d" 2>/dev/null || true
          chmod 0775 "$raw/$d" 2>/dev/null || true
        done
      fi
      if is_on "$FIX_POSTFSDATA_RESTORECON_DATA_MEDIA"; then
        restorecon -RF "$raw" >/dev/null 2>&1 || true
      fi
      echo "prepared raw shared storage: $raw"
    else
      echo "skipped: /data/media absent"
    fi
  else
    echo "disabled by config: FIX_POSTFSDATA_PREPARE_DATA_MEDIA"
  fi
  echo "===== post-fs-data done ====="
} >> "$LOG" 2>&1

exit 0
