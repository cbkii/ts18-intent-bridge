#!/system/bin/sh
# TS18 DocumentsUI SAF Full installer.
# Magisk 28.1 target. MMT-Extended-inspired explicit install flow with SKIPUNZIP=1.

SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true
SKIPUNZIP=1

CONFIG=/data/adb/ts18-documentsui-saf.conf
MODID=ts18_documentsui_saf_full

REQUIRE_SDK_29=1
REQUIRE_MAGISK_281=1
FIX_REMOVE_OLD_MODULES=1
FIX_REMOVE_USER_APK_SHADOWS=1

print_line() {
  ui_print "$1"
}

is_on() {
  case "$1" in
    1|true|TRUE|yes|YES|on|ON|enabled|ENABLED) return 0 ;;
    *) return 1 ;;
  esac
}

valid_scalar() {
  case "$1" in
    ''|*[!A-Za-z0-9_./:-]*) return 1 ;;
    *) return 0 ;;
  esac
}

load_config_safe() {
  cfg="$1"
  [ -f "$cfg" ] || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      ''|'#'*) continue ;;
      *=*) ;;
      *) continue ;;
    esac
    key=${line%%=*}
    val=${line#*=}
    case "$key" in
      REQUIRE_SDK_29|REQUIRE_MAGISK_281|FIX_REMOVE_OLD_MODULES|FIX_REMOVE_USER_APK_SHADOWS)
        if valid_scalar "$val"; then
          eval "$key=\$val"
        fi
        ;;
    esac
  done < "$cfg"
}

unzip_to_work() {
  work="$1"
  err="$TMPDIR/${MODID}-unzip.err"
  rm -rf "$work" 2>/dev/null || true
  mkdir -p "$work" || abort "! Cannot create installer work directory: $work"

  rm -f "$err" 2>/dev/null || true

  if command -v unzip >/dev/null 2>&1; then
    unzip -oq "$ZIPFILE" -d "$work" >/dev/null 2>"$err" && return 0
    print_line "- unzip failed; retrying with bundled BusyBox/toybox if available"
  fi

  if command -v busybox >/dev/null 2>&1; then
    rm -rf "$work"/* 2>/dev/null || true
    busybox unzip -oq "$ZIPFILE" -d "$work" >/dev/null 2>"$err" && return 0
  fi

  if [ -x /data/adb/magisk/busybox ]; then
    rm -rf "$work"/* 2>/dev/null || true
    /data/adb/magisk/busybox unzip -oq "$ZIPFILE" -d "$work" >/dev/null 2>"$err" && return 0
  fi

  if command -v toybox >/dev/null 2>&1; then
    rm -rf "$work"/* 2>/dev/null || true
    toybox unzip -o "$ZIPFILE" -d "$work" >/dev/null 2>"$err" && return 0
  fi

  print_line "! All unzip backends failed. Last unzip output:"
  if [ -f "$err" ]; then
    while IFS= read -r l || [ -n "$l" ]; do
      print_line "! $l"
    done < "$err"
  fi
  return 1
}

copy_extracted_module() {
  work="$1"

  [ -f "$work/module.prop" ] || abort "STOP: extracted module.prop missing; refusing partial install."
  [ -f "$work/service.sh" ] || abort "STOP: extracted service.sh missing; refusing partial install."
  [ -f "$work/post-fs-data.sh" ] || abort "STOP: extracted post-fs-data.sh missing; refusing partial install."
  [ -f "$work/uninstall.sh" ] || abort "STOP: extracted uninstall.sh missing; refusing partial install."
  [ -s "$work/system/priv-app/DocumentsUI/DocumentsUI.apk" ] || abort "STOP: extracted DocumentsUI.apk missing/empty; refusing partial install."
  [ -s "$work/system/priv-app/TS18LocalDocumentsProvider/TS18LocalDocumentsProvider.apk" ] || abort "STOP: extracted TS18LocalDocumentsProvider.apk missing/empty; refusing partial install."
  [ -f "$work/system/etc/permissions/privapp-permissions-ts18-documentsui.xml" ] || abort "STOP: privapp permission XML missing; refusing partial install."
  [ -f "$work/system/etc/default-permissions/default-permissions-ts18-documentsui.xml" ] || abort "STOP: default permission XML missing; refusing partial install."
  [ -f "$work/system/etc/permissions/privapp-permissions-ts18-externalstorage.xml" ] || abort "STOP: externalstorage privapp permission XML missing; refusing partial install."
  [ -f "$work/system/etc/default-permissions/default-permissions-ts18-externalstorage.xml" ] || abort "STOP: externalstorage default permission XML missing; refusing partial install."
  [ -f "$work/system/etc/default-permissions/default-permissions-ts18-safprovider.xml" ] || abort "STOP: TS18 safprovider default permission XML missing; refusing partial install."
  [ -f "$work/system/etc/sysconfig/ts18-documentsui-files-launcher.xml" ] || abort "STOP: sysconfig XML missing; refusing partial install."
  [ -f "$work/action.sh" ] || abort "STOP: action.sh missing; refusing partial install."
  [ -f "$work/tools/ts18-saf-diagnose.sh" ] || abort "STOP: diagnose tool missing; refusing partial install."
  [ -f "$work/tools/ts18-saf-launch.sh" ] || abort "STOP: launch tool missing; refusing partial install."

  rm -rf "$work/META-INF" 2>/dev/null || true
  rm -rf "$MODPATH"/* 2>/dev/null || true
  mkdir -p "$MODPATH" || abort "! Cannot create module path: $MODPATH"
  cp -Rfp "$work"/. "$MODPATH"/ || abort "! Copy from installer work directory to MODPATH failed."
  rm -rf "$MODPATH/META-INF" 2>/dev/null || true
}

print_line " "
print_line "TS18 DocumentsUI SAF Full v1.6"
print_line "- Magisk 28.1 package; store-only ZIP; explicit SKIPUNZIP installer."
print_line "- Installs AOSP Android 10 DocumentsUI as a systemless priv-app."
print_line "- Adds privapp and default runtime permission XML."
print_line "- Adds configurable boot-time fixes for SAF roots/provider and storage-volume state."
print_line "- Adds TS18LocalDocumentsProvider as a separate SAF provider root for internal storage fallback."
print_line "- Does not write to /system or /vendor. Reboot is required."
print_line "- Adds post-fs-data preparation, bounded late-start storage repair, and Magisk action diagnostics."
print_line " "

if is_on "$REQUIRE_MAGISK_281"; then
  case "${MAGISK_VER_CODE:-0}" in ''|*[!0-9]*) abort "STOP: Cannot determine Magisk version code." ;; esac
  [ "$MAGISK_VER_CODE" -ge 28100 ] || abort "STOP: This package targets Magisk 28.1+. Found MAGISK_VER=${MAGISK_VER:-unknown} MAGISK_VER_CODE=$MAGISK_VER_CODE."
fi

if is_on "$REQUIRE_SDK_29"; then
  [ "${API:-}" = "29" ] || abort "STOP: This module is packaged for TS18 Android 10 / API 29. Found API=${API:-unknown}."
fi

work="$TMPDIR/${MODID}-extract"
print_line "- Extracting module with guarded store-only ZIP path"
unzip_to_work "$work" || abort "STOP: guarded extraction failed; no module files were installed."
copy_extracted_module "$work"
print_line "- Extraction and self-validation completed"

if [ ! -f "$CONFIG" ]; then
  print_line "- Creating editable config: $CONFIG"
  mkdir -p /data/adb 2>/dev/null || true
  cp -f "$MODPATH/config.default" "$CONFIG" 2>/dev/null || true
  chmod 0644 "$CONFIG" 2>/dev/null || true
else
  print_line "- Preserving existing editable config: $CONFIG"
fi
load_config_safe "$CONFIG"

if is_on "${FIX_REMOVE_OLD_MODULES:-1}"; then
  for old in \
    ts18_docsui_aosp \
    ts18_docsui_aml \
    ts18_saf_roots_helper \
    ts18_safroots_helper \
    ts18_saf_roots \
    ts18_safroots \
    ts18_documentsui_aosp \
    ts18_documentsui_aml; do
    if [ -d "/data/adb/modules/$old" ]; then
      print_line "- Marking old module for removal: $old"
      touch "/data/adb/modules/$old/remove" 2>/dev/null || true
    fi
    if [ -d "/data/adb/modules_update/$old" ]; then
      print_line "- Removing pending old module update: $old"
      rm -rf "/data/adb/modules_update/$old" 2>/dev/null || true
    fi
  done
fi

if [ "${BOOTMODE:-false}" = "true" ] && is_on "${FIX_REMOVE_USER_APK_SHADOWS:-1}"; then
  for pkg in com.google.android.documentsui com.android.documentsui; do
    paths=$(pm path "$pkg" 2>/dev/null || true)
    case "$paths" in
      *package:/data/app/*)
        print_line "- Removing user-installed DocumentsUI package shadow: $pkg"
        pm uninstall --user 0 "$pkg" >/dev/null 2>&1 || true
        ;;
    esac
  done
fi

print_line "- Setting module file permissions"
set_perm_recursive "$MODPATH" 0 0 0755 0644 u:object_r:system_file:s0
set_perm_recursive "$MODPATH/system" 0 0 0755 0644 u:object_r:system_file:s0
set_perm "$MODPATH/service.sh" 0 0 0755 u:object_r:system_file:s0
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755 u:object_r:system_file:s0
set_perm "$MODPATH/uninstall.sh" 0 0 0755 u:object_r:system_file:s0
set_perm "$MODPATH/config.default" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/system/priv-app/DocumentsUI/DocumentsUI.apk" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/system/priv-app/TS18LocalDocumentsProvider/TS18LocalDocumentsProvider.apk" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/system/etc/permissions/privapp-permissions-ts18-documentsui.xml" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/system/etc/default-permissions/default-permissions-ts18-documentsui.xml" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/system/etc/permissions/privapp-permissions-ts18-externalstorage.xml" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/system/etc/default-permissions/default-permissions-ts18-externalstorage.xml" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/system/etc/default-permissions/default-permissions-ts18-safprovider.xml" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/system/etc/sysconfig/ts18-documentsui-files-launcher.xml" 0 0 0644 u:object_r:system_file:s0
set_perm "$MODPATH/action.sh" 0 0 0755 u:object_r:system_file:s0
set_perm_recursive "$MODPATH/tools" 0 0 0755 0755 u:object_r:system_file:s0

print_line " "
print_line "- Installed. Reboot required."
print_line "- Runtime config: $CONFIG"
print_line "- Boot log after reboot: /data/local/tmp/ts18-documentsui-saf-full.log"
print_line " "
