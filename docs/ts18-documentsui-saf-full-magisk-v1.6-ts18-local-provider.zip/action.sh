#!/system/bin/sh
# Magisk action button: launch ACTION_OPEN_DOCUMENT_TREE with advanced roots and primary-root initial URI.
MODDIR=${0%/*}
LOG=/data/local/tmp/ts18-documentsui-saf-action.log
{
  echo "===== TS18 SAF Magisk action $(date '+%F %T %z' 2>/dev/null || echo unknown-time) ====="
  "$MODDIR/tools/ts18-saf-diagnose.sh" quick || true
  "$MODDIR/tools/ts18-saf-launch.sh" ts18 || true
  echo "===== action done ====="
} >> "$LOG" 2>&1
exit 0
