#!/system/bin/sh
# Bounded local SAF diagnostics. Usage: ts18-saf-diagnose.sh [quick|full]
MODE=${1:-full}
OUT=/data/local/tmp/ts18-documentsui-saf-diagnose.txt
TARGET_USER=0
{
  echo "===== TS18 SAF diagnose $(date '+%F %T %z' 2>/dev/null || echo unknown-time) mode=$MODE ====="
  echo "identity=$(id 2>/dev/null)"
  echo "sdk=$(getprop ro.build.version.sdk 2>/dev/null) build=$(getprop ro.build.display.id 2>/dev/null)"
  echo "--- package paths ---"
  for p in com.android.documentsui com.google.android.documentsui com.ts18.safprovider com.android.externalstorage com.android.providers.downloads com.android.providers.media; do pm path "$p" 2>&1 || true; done
  echo "--- DocumentsUI resolution ---"
  cmd package resolve-activity --brief -a android.intent.action.OPEN_DOCUMENT_TREE 2>&1 || true
  cmd package query-activities -a android.intent.action.OPEN_DOCUMENT_TREE 2>&1 | head -n 120 || true
  echo "--- DocumentsUI permissions proof ---"
  pm dump com.android.documentsui 2>&1 | grep -E 'codePath=|privateFlags=|pkgFlags=|User 0:|android.permission.MANAGE_DOCUMENTS|GET_APP_GRANTED_URI_PERMISSIONS|REMOVE_TASKS|CACHE_CONTENT|READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE' | head -n 160 || true
  echo "--- TS18 Local DocumentsProvider proof ---"
  pm dump com.ts18.safprovider 2>&1 | grep -E 'codePath=|privateFlags=|pkgFlags=|User 0:|TS18DocumentsProvider|com.ts18.safprovider.documents|READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE' | head -n 180 || true
  echo "--- ExternalStorageProvider proof ---"
  pm dump com.android.externalstorage 2>&1 | grep -E 'codePath=|privateFlags=|pkgFlags=|User 0:|ExternalStorageProvider|MountReceiver|TestDocumentsProvider|WRITE_MEDIA_STORAGE|MOUNT_UNMOUNT_FILESYSTEMS|READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE' | head -n 180 || true
  echo "--- TS18 local provider roots ---"
  content --user "$TARGET_USER" query --uri content://com.ts18.safprovider.documents/root 2>&1 || content query --uri content://com.ts18.safprovider.documents/root 2>&1 || true
  echo "--- TS18 local provider internal children ---"
  content --user "$TARGET_USER" query --uri content://com.ts18.safprovider.documents/document/ts18_internal%3A/children 2>&1 || content query --uri content://com.ts18.safprovider.documents/document/ts18_internal%3A/children 2>&1 || true
  echo "--- ExternalStorageProvider roots ---"
  content --user "$TARGET_USER" query --uri content://com.android.externalstorage.documents/root 2>&1 || content query --uri content://com.android.externalstorage.documents/root 2>&1 || true
  echo "--- primary document ---"
  content --user "$TARGET_USER" query --uri content://com.android.externalstorage.documents/document/primary%3A 2>&1 || content query --uri content://com.android.externalstorage.documents/document/primary%3A 2>&1 || true
  echo "--- primary children ---"
  content --user "$TARGET_USER" query --uri content://com.android.externalstorage.documents/document/primary%3A/children 2>&1 || content query --uri content://com.android.externalstorage.documents/document/primary%3A/children 2>&1 || true
  echo "--- downloads roots ---"
  content --user "$TARGET_USER" query --uri content://com.android.providers.downloads.documents/root 2>&1 || content query --uri content://com.android.providers.downloads.documents/root 2>&1 || true
  echo "--- sm volumes ---"
  sm list-volumes all 2>&1 || sm list-volumes 2>&1 || true
  echo "--- mounts ---"
  grep -E ' /storage/| /mnt/runtime/| /mnt/media_rw|/data/media' /proc/mounts 2>/dev/null || true
  if [ "$MODE" = "full" ]; then
    echo "--- dumpsys mount/storage excerpt ---"
    dumpsys mount 2>&1 | grep -Ei 'VolumeInfo|emulated|public:|private|Primary|mPrimary|state=|path=|visible|fsUuid|internalPath' | head -n 220 || true
    dumpsys storage 2>&1 | grep -Ei 'VolumeInfo|emulated|public:|private|Primary|mPrimary|state=|path=|visible|fsUuid|internalPath' | head -n 220 || true
    echo "--- provider dumps ---"
    dumpsys activity provider com.ts18.safprovider/com.ts18.safprovider.TS18DocumentsProvider 2>&1 | head -n 180 || true
    dumpsys activity provider com.android.externalstorage/.ExternalStorageProvider 2>&1 | head -n 220 || true
    echo "--- recent logcat ---"
    logcat -d -t 500 2>/dev/null | grep -Ei 'TS18LocalDocumentsProvider|com.ts18.safprovider|DocumentsUI|ExternalStorage|DownloadStorageProvider|MediaDocumentsProvider|DocumentsProvider|MANAGE_DOCUMENTS|SecurityException|Failed to find provider|content://com.ts18.safprovider|content://com.android.externalstorage' | tail -n 180 || true
  fi
  echo "===== diagnose done ====="
} > "$OUT" 2>&1
cat "$OUT"
exit 0
