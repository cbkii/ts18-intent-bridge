#!/system/bin/sh
# Launch known SAF picker variants for TS18 testing. Usage: ts18-saf-launch.sh [ts18|primary|home|plain|files|all]
MODE=${1:-ts18}
LOG=/data/local/tmp/ts18-documentsui-saf-launch.log

launch_ts18() {
  am force-stop com.android.documentsui >/dev/null 2>&1 || true
  am start -a android.intent.action.OPEN_DOCUMENT_TREE \
    --eu android.provider.extra.INITIAL_URI 'content://com.ts18.safprovider.documents/root/ts18_internal' \
    --ez android.provider.extra.SHOW_ADVANCED true \
    --ez android.content.extra.SHOW_ADVANCED true \
    --ez android.provider.extra.SHOW_FILESIZE true \
    --ez android.content.extra.SHOW_FILESIZE true
}

launch_primary() {
  am force-stop com.android.documentsui >/dev/null 2>&1 || true
  am start -a android.intent.action.OPEN_DOCUMENT_TREE \
    --eu android.provider.extra.INITIAL_URI 'content://com.android.externalstorage.documents/root/primary' \
    --ez android.provider.extra.SHOW_ADVANCED true \
    --ez android.content.extra.SHOW_ADVANCED true \
    --ez android.provider.extra.SHOW_FILESIZE true \
    --ez android.content.extra.SHOW_FILESIZE true
}
launch_home() {
  am force-stop com.android.documentsui >/dev/null 2>&1 || true
  am start -a android.intent.action.OPEN_DOCUMENT_TREE \
    --eu android.provider.extra.INITIAL_URI 'content://com.android.externalstorage.documents/root/home' \
    --ez android.provider.extra.SHOW_ADVANCED true \
    --ez android.content.extra.SHOW_ADVANCED true
}
launch_plain() {
  am force-stop com.android.documentsui >/dev/null 2>&1 || true
  am start -a android.intent.action.OPEN_DOCUMENT_TREE \
    --ez android.provider.extra.SHOW_ADVANCED true \
    --ez android.content.extra.SHOW_ADVANCED true
}
launch_files() {
  am force-stop com.android.documentsui >/dev/null 2>&1 || true
  am start -n com.android.documentsui/.files.FilesActivity \
    --ez android.provider.extra.SHOW_ADVANCED true \
    --ez android.content.extra.SHOW_ADVANCED true
}
{
  echo "===== TS18 SAF launch $(date '+%F %T %z' 2>/dev/null || echo unknown-time) mode=$MODE ====="
  cmd package resolve-activity --brief -a android.intent.action.OPEN_DOCUMENT_TREE 2>&1 || true
  case "$MODE" in
    ts18) launch_ts18 ;;
    primary) launch_primary ;;
    home) launch_home ;;
    plain) launch_plain ;;
    files) launch_files ;;
    all) launch_ts18; sleep 2; launch_primary; sleep 2; launch_home; sleep 2; launch_plain ;;
    *) echo "Unknown mode: $MODE"; exit 2 ;;
  esac
  echo "===== launch done ====="
} >> "$LOG" 2>&1
exit 0
