#!/system/bin/sh
LOG=/data/local/tmp/ts18-documentsui-saf-full.log
{
  echo "===== uninstall ts18_documentsui_saf_full ====="
  date 2>/dev/null || true
  echo "Module removed. Reboot required."
  echo "Editable config remains at /data/adb/ts18-documentsui-saf.conf. Delete it manually if you want a clean reinstall."
  echo "DocumentsUI preference/database backups, if any, remain under /data/user/0/com.android.documentsui or /data/data/com.android.documentsui with .ts18bak suffixes."
  echo "If com.google.android.documentsui was deliberately used before, re-enable it manually after reboot if needed: pm enable --user 0 com.google.android.documentsui"
} >> "$LOG" 2>&1
exit 0

# v1.6: provider APK is systemless and is removed with the module. Keep app data for audit unless user clears it manually.
