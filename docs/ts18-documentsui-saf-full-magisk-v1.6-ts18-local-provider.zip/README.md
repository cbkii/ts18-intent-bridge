# TS18 DocumentsUI SAF Full v1.6

Observed TS18 evidence showed DocumentsUI could launch but the stock `com.android.externalstorage.documents` provider did not publish a `primary` root. v1.6 therefore keeps the AOSP Android 10 DocumentsUI priv-app but adds a separate, minimal `TS18LocalDocumentsProvider` priv-app.

The new provider authority is:

```text
com.ts18.safprovider.documents
```

It exposes read-only SAF roots for:

```text
TS18 Internal Storage -> /storage/emulated/0
TS18 Download          -> /storage/emulated/0/Download
TS18 Documents         -> /storage/emulated/0/Documents
TS18 Music             -> /storage/emulated/0/Music
TS18 Pictures          -> /storage/emulated/0/Pictures
TS18 Movies            -> /storage/emulated/0/Movies
TS18 USB Disk 0        -> /storage/usbdisk0
TS18 USB Disk 1        -> /storage/usbdisk1
```

This is a provider-side bypass for a broken ExternalStorageProvider primary root. It does not replace vold, MediaProvider, DownloadProvider, DoFun, MCU/CAN, radio, Bluetooth, or any vendor services.

## Main config toggles

Runtime config is created at:

```text
/data/adb/ts18-documentsui-saf.conf
```

Important v1.6 toggles:

```text
FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER=1
FIX_GRANT_TS18_LOCAL_SAF_PROVIDER_RUNTIME_PERMS=1
FIX_SET_TS18_LOCAL_SAF_PROVIDER_APPOPS=1
FIX_ENABLE_TS18_LOCAL_SAF_PROVIDER_COMPONENTS=1
FIX_WAIT_FOR_TS18_LOCAL_SAF_ROOT=1
```

## Validation after reboot

```sh
su -c 'tail -360 /data/local/tmp/ts18-documentsui-saf-full.log'
su -c 'content --user 0 query --uri content://com.ts18.safprovider.documents/root'
su -c 'content --user 0 query --uri content://com.ts18.safprovider.documents/document/ts18_internal%3A/children'
su -c '/data/adb/modules/ts18_documentsui_saf_full/tools/ts18-saf-diagnose.sh quick'
su -c '/data/adb/modules/ts18_documentsui_saf_full/tools/ts18-saf-launch.sh ts18'
```

## Stop conditions

STOP if `com.ts18.safprovider` is not installed as `/system/priv-app/TS18LocalDocumentsProvider/TS18LocalDocumentsProvider.apk` after reboot.

STOP if the TS18 provider root query returns `SecurityException` or `Failed to find provider`; that indicates package parsing/provider registration failed.

STOP if the provider appears but every root shows empty while `/storage/emulated/0` has content; that indicates storage permission or Android namespace access still needs device-side validation.
